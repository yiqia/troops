/*
    @author: 付伟琪
    @function：
    @date 2021-01-31 13:59
*/
const mongoose = require("mongoose");
require("../config/mongodb");
const Results = mongoose.model("Results", new mongoose.Schema({
    name: {type: String},
    high_bar: {type: Number},
    parallel_bars: {type: Number},
    tree_kilometers: {type: Number},
    gun_dis: {type: Number},
    rapid_reload: {type: Number},
    ten_protection: {type: Number},
    run: {type: Number},
    date: {type: String}
}));

module.exports = {
    Results
};
