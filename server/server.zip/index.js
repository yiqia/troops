/*
    @author: 付伟琪
    @function：
    @date 2021-01-30 22:32
*/
const express = require('express');
const url  = require('url');
const app = express();

app.use(require('cors')());
app.use(express.json());

const userRouter = require('./router/User')
const resultRouter = require('./router/Results')

app.use('/user',userRouter)
app.use('/result',resultRouter)




app.get('/',async (req,res)=>{
    res.send('hello')
})

app.listen(3001,()=>{
    console.log('http://localhost:3001/')
})
