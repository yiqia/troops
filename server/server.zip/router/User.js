/*
    @author: 付伟琪
    @function：
    @date 2021-01-31 11:42
*/
const express = require('express');
const router = express.Router();
const {User} = require('../db/User')

router.post('/addUser',async (req,res)=>{
    let result = null;
    if(req.body['_id']){
        const Id = req.body['_id'];
        delete req.body['_id'];
        result = await User.updateOne({'_id':Id},req.body);
    }else{
        result = await User.create(req.body);
    }

    res.json({
        code: 200,
        msg: 'ok',
        data: result,
    });
})
router.get('/getUser',async (req,res)=>{
    const start = req.query.page>0?req.query.page-1:req.query.page;
    const result = await Promise.all([
        User.count(),
        User.find().skip(start*10).limit(10)
    ]);
    res.json({
        code: 200,
        msg: 'ok',
        data: {
            count: result[0],
            list: result[1]
        },
    });
})
router.get('/delUser',async (req,res)=>{
    const Id = req.query['Id'];
    const result = await User.findOneAndDelete({'_id':Id})
    res.json({
        code: 200,
        msg: 'ok',
        data: result,
    });
})
router.post('/searchUser',async (req,res)=>{
    const start = req.body.page>0?req.body.page-1:req.body.page;
    const reg = new RegExp(req.body.name, 'i')
    const result = await Promise.all([
        User.find({'name':reg}).count(),
        User.find({'name':reg}).skip(start*10).limit(10)
    ]);
    res.json({
        code: 200,
        msg: 'ok',
        data: {
            count: result[0],
            list: result[1]
        }
    });
})



module.exports = router;
